//
//  CurrentController.swift
//  Final Project
//
//  Created by Utz, Michael Paul on 4/11/24.
//
//  Luke Vellines, Michael utz
//  lvelline, mutz
//  Boss's Orders
// Apr 26
import Foundation

protocol CurrentController {
    func updateClocks()
}
