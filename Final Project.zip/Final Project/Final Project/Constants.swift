//
//  Constants.swift
//  Final Project
//
//  Created by Luke Vellines on 4/19/24.
//
//  Luke Vellines, Michael utz
//  lvelline, mutz
//  Boss's Orders
// Apr 26
import Foundation
let darkModeKey = "darkModeEnabled"
let difficultyKey = "difficultySet"
